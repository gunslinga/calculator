package com.calculator.app;

import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class mainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView display,answer;
    materialButton buttonClear, buttonSign, buttonSqrt, buttonRootN, buttonPower, buttonSquare, buttonExponent, buttonReciprocal;
    materialButton button1, button2, button3, button4, button5, button6, button7, button8, button9;
    materialButton buttonDivide, buttonMultiply, buttonSubtract, buttonAdd, buttonEquals, buttonDecimal;

    @Override
    public void onClick(View view) {

    }
}


